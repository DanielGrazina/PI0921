import sqlite3

class Conta:
    def __init__(self, numconta: int, saldo: float):
        self.numconta = numconta
        self.saldo = saldo
        self.limite = 0
        self.transacoes = []
    
    #Levantar dinheiro
    def levantamento(self, valor):
        if self.saldo - valor < 0:
            print("Saldo insufeciente para levantar essa quantia!!")
        elif valor > 500:
            print("Não é possivel levantar mais de 500€ de cada vez!!")
        elif self.limite >= 2500:
            print("Excedeu o limite máximo diário para levantamento 2500€!!")
        else:
            self.saldo = self.saldo-valor
            print(f"Levantamento feito com sucesso.\n Levantou {valor} €. Saldo: {self.saldo} €.")
            self.limite = self.limite+valor
            self.transacoes.append(f"Levantamento de {valor}€")

    #Depositar dinheiro
    def depositar(self, valor):
        self.saldo=self.saldo+valor
        print(f"Deposito feito com sucesso.\n Depositou {valor} €. Saldo: {self.saldo} €. ")
        self.transacoes.append(f"Depósito de {valor}€")
    
    #Transferencia de dinheiro
    def transferencia(self, ContaDest, valor):
        if self.saldo - valor < 0:
            print("Saldo insufeciente para concluir a transferencia.")
        else:
            self.saldo = self.saldo - valor
            ContaDest.saldo = ContaDest.saldo + valor
            print(f"Transferencia feita com sucesso.\n Transferiu {valor} € para a conta {ContaDest.numconta}. Saldo: {self.saldo}")
            self.transacoes.append(f"Transferencia de {valor}€ para conta {ContaDest.numconta}")
    
    #Extrato
    def extrato(self):
        print(f"Extrato:\n Numero da conta {self.numconta} \n Saldo atual: {self.saldo}€")
        print("\nMovimentos da conta:\n")
        for transacao in self.transacoes:
            print(transacao)

class ATM:
    
    #Conecção com DataBase e verificação da tabela
    def __init__(self):
        self.contas = {}
        self.conexao = sqlite3.connect('contas.db')
        self.cursor = self.conexao.cursor()
        self.cursor.execute('''
            CREATE TABLE IF NOT EXISTS conta (
                            numconta INTEDER PRIMARY KEY,
                            saldo FLOAT
            )
        ''')
    
    #Introduzir valores na DataBase
    def adicionar_conta(self, numconta, saldo):
        self.contas[numconta] = Conta(numconta, saldo)
        self.cursor.execute('INSERT  OR IGNORE INTO conta VALUES (?, ?)', (numconta, saldo))
        self.conexao.commit()

    #Conta selecionada
    def selecionar(self, numconta):
        return self.contas[numconta]
    
    #Menu
    def menu(self):
        print("Bem-vindo ao MultiBanco!\n")

        #Opções
        while True:
            print("\n1 - Selecionar conta")
            print("2 - Levantar dinheiro")
            print("3 - Depositar dinheiro")
            print("4 - Transferir dinheiro")
            print("5 - Consultar extrato")
            print("0 - Sair")

            opcao = input("\nOpção: ")

            #Selecionar Conta
            if opcao == '1':
                numconta  = int(input("Número da conta: "))
                if numconta in self.contas:
                    print("Conta selecionada com sucesso!")
                    self.conta_selecionada = self.selecionar(numconta)
                else:
                    print("ERRO!! Conta Inválida!!")
            
            #Levantamento de dinheiro
            elif opcao == '2':
                if hasattr(self, 'conta_selecionada'):
                    valor = float(input("Quanto deseja levantar?\n"))
                    self.conta_selecionada.levantamento(valor)
                else:
                    print("Selecione uma conta primeiro.")

            #Deposito de dinheiro
            elif opcao == '3':
                if hasattr(self, 'conta_selecionada'):
                    valor = float(input("Quanto deseja depositar?\n"))
                    self.conta_selecionada.depositar(valor)
                else:
                    print("Selecione uma conta primeiro.")
            
            #Transferencia de dinheiro
            elif opcao == '4':
                if hasattr(self, 'conta_selecionada'):
                    ContaDest = int(input("Número da conta de destino: "))
                    if ContaDest in self.contas:
                        valor = float(input("Valor a tranferir: "))
                        self.conta_selecionada.transferencia(self.contas[ContaDest], valor)
                    else:
                        print("ERRO!! Conta destino inválida!")
                else:
                    print("Selecione conta primeiro.")
            
            #Extrato
            elif opcao == '5':
                if hasattr(self, 'conta_selecionada'):
                    self.conta_selecionada.extrato()
                else:
                    print("Selecione conta primeiro.")

            #Sair
            elif opcao == '0':
                print("Obrigado por utilizar o Multibanco!")
                break

#Contas para teste
if __name__ == '__main__':
    caixa = ATM()
    caixa.adicionar_conta(123, 1000)
    caixa.adicionar_conta(321, 1000)
    caixa.menu()